import cv2
import mediapipe as mp
import time

# Mediapipe setup
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)
mp_draw = mp.solutions.drawing_utils

# Camera setup
cap = cv2.VideoCapture(0)

prev_hand_y = None
prev_hand_x = None
person_present = False
last_detection_time = time.time()

# Constants
MOTION_TIMEOUT = 3        # seconds to consider no motion
SHUTDOWN_TIMEOUT = 600    # 10 minutes before shutdown (600 seconds)
GESTURE_THRESHOLD = 30    # pixel threshold for movement
FEEDBACK_DURATION = 2     # <-- CHANGED: How long feedback text stays on screen (in seconds)

# Device states
lights_on = False
fan_on = False
router_on = False
brightness_level = 50     # percentage
fan_speed = 1             # arbitrary units (1–5 for example)

# Feedback message variables <-- CHANGED
feedback_text = ""
feedback_time = 0


def detect_person(results):
    """Check if a person is present using pose landmarks."""
    return results.pose_landmarks is not None


def detect_hand_movement(hand_landmarks, frame):
    """Detect hand movement gestures for fan/light control."""
    global prev_hand_y, prev_hand_x

    current_x = hand_landmarks.landmark[mp_hands.HandLandmark.WRIST].x
    current_y = hand_landmarks.landmark[mp_hands.HandLandmark.WRIST].y

    height, width, _ = frame.shape
    cx = int(current_x * width)
    cy = int(current_y * height)

    gesture = None

    if prev_hand_y is not None and prev_hand_x is not None:
        dy = cy - prev_hand_y
        dx = cx - prev_hand_x

        if abs(dy) > abs(dx) and abs(dy) > GESTURE_THRESHOLD:
            if dy < 0:
                gesture = "increase_brightness"
            else:
                gesture = "decrease_brightness"
        elif abs(dx) > abs(dy) and abs(dx) > GESTURE_THRESHOLD:
            if dx > 0:
                gesture = "fan_speed_up"
            else:
                gesture = "fan_speed_down"

    prev_hand_y = cy
    prev_hand_x = cx

    return gesture


while True:
    success, frame = cap.read()
    if not success:
        break

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Initialize default status text for this frame
    status_text = ""

    # Detect person & hands
    pose_results = pose.process(frame_rgb)
    hand_results = hands.process(frame_rgb)

    # Person detection logic
    person_present = detect_person(pose_results)

    if person_present:
        lights_on, fan_on, router_on = True, True, True
        status_text = "Lights & fan are ON."
        last_detection_time = time.time()
    else:
        # Time since last person detected
        elapsed = time.time() - last_detection_time
        if elapsed > SHUTDOWN_TIMEOUT:
            lights_on, fan_on, router_on = False, False, False
            status_text = "System shutdown: lights, fan & router OFF."
        elif elapsed > MOTION_TIMEOUT:
            lights_on, fan_on, router_on = False, False, False
            status_text = "Sleep mode: devices idle."
        else:
            status_text = "Lights & fan remain ON."

    # Hand gesture detection (manual overrides)
    if hand_results.multi_hand_landmarks:
        gesture = detect_hand_movement(hand_results.multi_hand_landmarks[0], frame)
        if gesture:
            feedback_time = time.time() # <-- CHANGED: Reset timer on new gesture
            if gesture == "increase_brightness" and lights_on:
                brightness_level = min(100, brightness_level + 10)
                feedback_text = f"Brightness increased to {brightness_level}%" # <-- CHANGED
            elif gesture == "decrease_brightness" and lights_on:
                brightness_level = max(0, brightness_level - 10)
                feedback_text = f"Brightness decreased to {brightness_level}%" # <-- CHANGED
            elif gesture == "fan_speed_up" and fan_on:
                fan_speed = min(5, fan_speed + 1)
                feedback_text = f"Fan speed increased to {fan_speed}" # <-- CHANGED
            elif gesture == "fan_speed_down" and fan_on:
                fan_speed = max(0, fan_speed - 1)
                feedback_text = f"Fan speed decreased to {fan_speed}" # <-- CHANGED

        mp_draw.draw_landmarks(frame, hand_results.multi_hand_landmarks[0], mp_hands.HAND_CONNECTIONS)
    else:
        prev_hand_x, prev_hand_y = None, None

    # Draw pose landmarks
    if pose_results.pose_landmarks:
        mp_draw.draw_landmarks(frame, pose_results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # Show feedback text if recent gesture
    if feedback_text and (time.time() - feedback_time < FEEDBACK_DURATION):
        cv2.putText(frame, feedback_text, (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)

    # Show status text
    cv2.putText(frame, status_text, (30, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

    cv2.imshow("Smart Room", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()